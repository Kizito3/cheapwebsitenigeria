<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cheap Website Nigeria</title>
    <link rel="icon" href="./asset/images/Cheap Website Logo White 1.png">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"> -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css">

    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous"> -->
    <link rel="stylesheet" href="css/animate.css">
</head>
<body>
        <?php
            include("include/nav.php");
        ?>
        <div class="inner-banner">
                <section class="w3l-breadcrumb">
                    <div class="container">
                        <h4 class="inner-text-title font-weight-bold text-white mb-sm-3 mb-2">About Us</h4>
                        <ul class="breadcrumbs-custom-path">
                            <li><a href="index.php">Home</a></li>
                            <li class="active"><span class="fa fa-chevron-right mx-2" aria-hidden="true"></span>About Us</li>
                        </ul>
                    </div>
                </section>
        </div>

        <section class="about1 mb-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <h3>About Us</h3>
                    </div>
                </div>
            </div>
        </section>

        <section>
            <div class="container about mb-5">
                <div class="row">
                    <div class="col-md-5">
                        <h4 class="mb-4">At cheap website Nigeria, our mission is to provide affordable and high-quality website solutions to businesses of all sizes. </h4>
                        <p>We believe that every business, regardless of their budget, deserves to have a professional and effective online presence
                        We're there for you whenever you need IT experts with a know-how for building beautiful websites that get the job done. And our output always comes in bundle with reasonable pricing and G.O.A.T client service.</p>
                        <p>
                      
                    </div>
                    <div class="col-md-1"></div>
                    <div class="col-md-5">
                        <img src="./asset/images/bigstock.png" class="img-fluid" alt="">
                    </div>
                </div>
            </div>
        </section>
    
        <section>
    <div class="container wow slideInRight" data-wow-duration="2s" data-wow-delay="1s">
    <div class="row get-in-touch mb-5 mt-5">
                    <div class="col-md-5">
                        <div class="question">
                            <h5>Still have questions?</h5>
                            <p>Can’t find the answer you’re looking for? Please chat to our friendly team.</p>
                        </div>
                    </div>
                        <div class="col-md-5"></div>
                    <div class="col-md-2">
                        <div class="get-btn mt-3">
                            <a href=""><button>Get in touch</button></a>
                        </div>
                    </div>
                </div>
    </div>
  </section>


  <?php
  include("include/footer.php");
  ?>




        <script src="js/wow.min.js"></script>
              <script>
              new WOW().init();
              </script>
    <script src="js/scrpt.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>